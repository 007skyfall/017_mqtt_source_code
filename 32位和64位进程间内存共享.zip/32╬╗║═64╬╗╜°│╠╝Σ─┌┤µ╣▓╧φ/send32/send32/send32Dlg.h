
// send32Dlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "MEMMAP.h"

const char MEM_MAP_FILE_NAME[] = { "Q_MEM_MAP_FILE" };

// Csend32Dlg �Ի���
class Csend32Dlg : public CDialogEx
{
// ����
public:
	Csend32Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_SEND32_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

public:
	CMemMapFile memMap;
// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnDestroy();
	CString SendContentEdit;
};
