#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTTClient.h"
#define ADDRESS "tcp://192.168.0.101:1883"
//#define ADDRESS "localhost:1883"
#define CLIENTID "windows"
#define PAYLOAD "hello I am pub!"
#define TOPIC "MQTT Examples/hello I am windows"
#define TIMEOUT 10000L
#pragma comment(lib,"paho-mqtt3c.lib")

int main(int argc, const char *argv[])
{
	printf("I am pub!\n");
	MQTTClient client;
	MQTTClient_connectOptions conn_opts=MQTTClient_connectOptions_initializer;
	MQTTClient_message pubmsg=MQTTClient_message_initializer;
	MQTTClient_deliveryToken token;
	int rc;
	MQTTClient_create(&client,ADDRESS,CLIENTID,MQTTCLIENT_PERSISTENCE_NONE,NULL);
	conn_opts.keepAliveInterval = 100000;
	conn_opts.cleansession = 1; 

	if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
	{
		printf("Failed to connect, return code %d\n", rc);
		exit(EXIT_FAILURE);
	}
#if 0
	pubmsg.payload = PAYLOAD;
	pubmsg.payloadlen = strlen(PAYLOAD);
	pubmsg.qos = 1;
	pubmsg.retained = 0;
#endif
	char sendmsg[128];
	int len;
	while(1)
	{
#if 1
		scanf("%s",sendmsg);
		pubmsg.payload = sendmsg;
		pubmsg.payloadlen = strlen(sendmsg);
		pubmsg.qos = 1;
		pubmsg.retained = 0;
#endif
		MQTTClient_publishMessage(client,TOPIC,&pubmsg,&token);
		printf("Waiting for up to %d seconds for publication of %s\n"
				             "on topic %s for client with ClientID: %s\n",
							             (int)(TIMEOUT/1000), PAYLOAD, TOPIC, CLIENTID);
		rc=MQTTClient_waitForCompletion(client,token,TIMEOUT);
		printf("Message wait delivery token %d delivered\n",token);
	}
	MQTTClient_disconnect(client, 10000);
	MQTTClient_destroy(&client);
	return rc;
}
